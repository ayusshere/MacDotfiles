return {
  {
    "akinsho/toggleterm.nvim",
    version = "*",
    keys = {
      -- Toggle terminal in current file's directory (Mac: cmd+/)
      {
        "<D-/>",
        function()
          local current_dir = vim.fn.expand("%:p:h") -- Get current file's directory
          local toggleterm = require("toggleterm")
          local Terminal = require("toggleterm.terminal").Terminal

          -- Check if a terminal already exists for this buffer
          if not _G.my_custom_terminal then
            _G.my_custom_terminal = Terminal:new({
              dir = current_dir,
              direction = "horizontal",
              size = 15,
              on_close = function() -- Clean up on exit
                _G.my_custom_terminal = nil
              end,
            })
          end

          _G.my_custom_terminal:toggle() -- Toggle the terminal
        end,
        desc = "Toggle Terminal (Current Dir)",
        mode = { "n", "i", "t" },
      },
      -- Fallback for Linux/Windows (leader+/)
      {
        "<leader>/",
        function()
          local current_dir = vim.fn.expand("%:p:h") -- Get current file's directory
          local toggleterm = require("toggleterm")
          local Terminal = require("toggleterm.terminal").Terminal

          if not _G.my_custom_terminal then
            _G.my_custom_terminal = Terminal:new({
              dir = current_dir,
              direction = "horizontal",
              size = 15,
              on_close = function()
                _G.my_custom_terminal = nil
              end,
            })
          end

          _G.my_custom_terminal:toggle()
        end,
        desc = "Toggle Terminal (Current Dir)",
        mode = { "n", "i", "t" },
      },
    },
    opts = {
      open_mapping = false, -- Disable default toggleterm mapping
      start_in_insert = true,
      persist_size = true,
      close_on_exit = true,
    },
  },
}
