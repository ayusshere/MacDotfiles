return {
  {
    "catppuccin/nvim",
    name = "catppuccin",
    lazy = false,
    priority = 1000,
    opts = {
      flavour = "mocha",
      transparent_background = true,

      highlight_overrides = {
        mocha = function(colors)
          return {
            Normal = { bg = "none" },
            NormalFloat = { bg = "none" },
            SignColumn = { bg = "none" },
            CursorLine = { bg = "#313244" },
            CursorLineNr = { fg = colors.yellow, bold = true },
            FloatBorder = { bg = "none", fg = "#585b70" },
            Pmenu = { bg = colors.crust },
            Comment = { fg = colors.overlay2, style = {} }, -- <- no italic
          }
        end,
      },
    },

    config = function(_, opts)
      require("catppuccin").setup(opts)
      vim.cmd.colorscheme("catppuccin")
    end,
  },
}
