-- ~/.config/nvim/lua/plugins/gitsigns.lua
return {
  {
    "lewis6991/gitsigns.nvim",
    enabled = false,
  },
}
