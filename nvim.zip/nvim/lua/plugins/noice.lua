-- ~/.config/nvim/lua/plugins/noice.lua
return {
  "folke/noice.nvim",
  opts = {
    lsp = {
      -- Disable LSP progress popups
      progress = { enabled = false },
      -- Disable "Formatting" messages
      signature = { enabled = false },
    },
  },
}
