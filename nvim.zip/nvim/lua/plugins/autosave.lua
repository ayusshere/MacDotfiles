return {
  {
    "Pocco81/auto-save.nvim",
    config = function()
      require("auto-save").setup({
        enabled = true,
        trigger_events = { "InsertLeave", "TextChanged" },
        debounce_delay = 1000,
        -- Disable notifications
        execution_message = {
          message = "", -- Empty string means no message
          dim = 0.18,  -- Dim color (optional)
          cleaning_interval = 1250, -- How often to clear the message (ms)
        },
        noautocmd = false, -- Set to `true` to disable autocmd messages (optional)
      })
    end,
  }
}
